
package view;

import javax.swing.JButton;
import javax.swing.JFrame;


public class TestSwing {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Stock MGT System");
        JButton btn = new JButton();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        btn.setText("Register");
//        btn.setVisible(true);
        frame.add(btn);
        frame.setSize(600, 700);
        frame.setVisible(true);
    }
}
