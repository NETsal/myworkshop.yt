package dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.Product;



public class ProductDao {
    
    private final String dbUrl = "jdbc:mysql://localhost:3306/tuesday_evening_db";
    private final String username = "root";
    private final String password = "auca123";

    
    public ProductDao() {
    }

    
    public String registerProductPrepared(Product productObj) {
        try {
            int rowAffected;
            
            try ( 
                    Connection con = DriverManager.getConnection(dbUrl, username, password)) {
                
                String sql = "INSERT INTO product (product_id, product_name, price) VALUES (?, ?, ?)";
                PreparedStatement pst = con.prepareStatement(sql);
                pst.setString(1, productObj.getProductId());
                pst.setString(2, productObj.getProductName());
                pst.setDouble(3, productObj.getPrice());
                
                rowAffected = pst.executeUpdate();
                
            }

            if (rowAffected >= 1) {
                return "Data Saved Successfully";
            } else {
                return "Data Not Saved";
            }
        } catch (SQLException ex) {
            return "Server Error: " + ex.getMessage();
        }
    }

    public String updateProduct(Product theProduct) {
    try {
        int rowsAffected;
        
        try (Connection con = DriverManager.getConnection(dbUrl, username, password)) {
            
            String sql = "UPDATE product SET product_name = ?, price = ? WHERE product_id = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, theProduct.getProductName());
            pst.setDouble(2, theProduct.getPrice());
            pst.setString(3, theProduct.getProductId());
            
           
            rowsAffected = pst.executeUpdate();
        }

        if (rowsAffected >= 1) {
            return "Product updated successfully";
        } else {
            return "Product update failed";
        }
    } catch (SQLException ex) {
        return "Server Error: " + ex.getMessage();
    }
}

   public String deleteProduct(String productId) {
    try {
        int rowsAffected;
       
        try (Connection con = DriverManager.getConnection(dbUrl, username, password)) {
           
            String sql = "DELETE FROM product WHERE product_id = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, productId);
            
            
            rowsAffected = pst.executeUpdate();
        }

        if (rowsAffected >= 1) {
            return "Product deleted successfully";
        } else {
            return "Product not found or delete failed";
        }
    } catch (SQLException ex) {
        return "Server Error: " + ex.getMessage();
    }
}
}

    