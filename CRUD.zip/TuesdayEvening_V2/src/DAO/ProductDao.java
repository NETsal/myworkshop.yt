package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.Product;

public class ProductDao {
    private final String dbUrl = "jdbc:mysql://localhost:3306/tuesday_evening_db";
    private final String username = "root";
    private final String password = "auca123";

    public ProductDao() {
    }

    // Insert a product into the database
    public String registerProduct(Product productObj) {
        try (Connection con = DriverManager.getConnection(dbUrl, username, password)) {
            String sql = "INSERT INTO product (product_id, product_name, price) VALUES (?, ?, ?)";

            try (PreparedStatement pst = con.prepareStatement(sql)) {
                pst.setString(1, productObj.getProductId());
                pst.setString(2, productObj.getProductName());
                pst.setDouble(3, productObj.getPrice());

                int rowAffected = pst.executeUpdate();

                if (rowAffected >= 1) {
                    return "Data Saved Successfully";
                } else {
                    return "Data Not Saved";
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace(); // Print the exception for debugging
            return "Server Error: " + ex.getMessage();
        }
    }

    // Other CRUD operations can be added similarly

    public String registerProductPrepared(Product productObj) {
        try (Connection con = DriverManager.getConnection(dbUrl, username, password)) {
            String sql = "INSERT INTO product (product_id, product_name, price) VALUES (?, ?, ?)";

            try (PreparedStatement pst = con.prepareStatement(sql)) {
                pst.setString(1, productObj.getProductId());
                pst.setString(2, productObj.getProductName());
                pst.setDouble(3, productObj.getPrice());

                int rowAffected = pst.executeUpdate();

                if (rowAffected >= 1) {
                    return "Data Saved Successfully";
                } else {
                    return "Data Not Saved";
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace(); // Print the exception for debugging
            return "Server Error: " + ex.getMessage();
        }
    }
}