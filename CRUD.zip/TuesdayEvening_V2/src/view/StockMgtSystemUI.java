package view;

import DAO.ProductDao;
import model.Product;

import java.util.Scanner;

public class StockMgtSystemUI {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean running = true;

        while (running) {
            printMainMenu();

            int choice = sc.nextInt();
            sc.nextLine(); 

            switch (choice) {
                case 1:
                    createProduct(sc);
                    break;
                case 2:
                    // Implement update product
                    break;
                case 3:
                    // Implement delete product
                    break;
                case 4:
                    // Implement retrieve all products
                    break;
                case 5:
                    // Implement search product by id
                    break;
                case 6:
                    createProductPrepared(sc);
                    break;
                case 0:
                    running = false;
                    System.out.println("Thank you for using the system");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void printMainMenu() {
        System.out.println("========================");
        System.out.println("Stock Management System");
        System.out.println("-------------------------");
        System.out.println("1. Create A Product");
        System.out.println("2. Update A Product");
        System.out.println("3. Delete A Product");
        System.out.println("4. Retrieve All Product");
        System.out.println("5. Search Product by id");
        System.out.println("6. Insert Product by Prepared");
        System.out.println("0. Exit");
        System.out.println("------------");
        System.out.print("Choose: ");
    }

    private static void createProduct(Scanner sc) {
        System.out.print("Enter Product ID  : ");
        String productId = sc.nextLine();
        System.out.print("Enter Product Name: ");
        String productName = sc.nextLine();
        System.out.print("Enter Price       : ");
        double price = sc.nextDouble();

        Product product = new Product(productId, productName, price);
        ProductDao dao = new ProductDao();
        String feedback = dao.registerProduct(product);

        System.out.println(feedback);
    }

    private static void createProductPrepared(Scanner sc) {
        System.out.print("Enter Product ID  : ");
        String productId = sc.nextLine();
        System.out.print("Enter Product Name: ");
        String productName = sc.nextLine();
        System.out.print("Enter Price       : ");
        double price = sc.nextDouble();

        Product product = new Product(productId, productName, price);
        ProductDao dao = new ProductDao();
        String feedback = dao.registerProductPrepared(product);

        System.out.println(feedback);
    }
}